# How To Write Terraform Scripts

This document will try to capture the workflow of writing terraform scripts. These documents are written in the context of Azure; please consult the relevant hashicorp terraform docs for other environments.

## Resources

Resources is a generic term referring to any entity in the environment. Some examples of Resources include: VNet, App Service, Blob Storage. Each resource includes Reference Documentation that links to the official terraform.io docs.

[azurerm reference docs main page](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs)

### App Service Plan

[Reference Documentation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan)

1. Copy the example resource code

```
resource "azurerm_service_plan" "example" {
  name                = "example"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_resource_group.example.location
  os_type             = "Linux"
  sku_name            = "P1v2"
}
```

2. Add it to the terraform main.tf file (add to a different file if using a more complex file structure)
3. Give the resource a name `resource "azurerm_service_plan" "<name goes here>" {`
4. Update the location and resource group name arguments to use the resource group resource (e.g. Given resource group definition `data "azurerm_resource_group" "rg" {`, the location argument would have a value of `data.azurerm_resource_group.rg.location`)
5. Update the name, os_type, and sku_name arguments. The Name argument is what the plan will be called inside the azure portal. Be aware of the sku_name argument as this argument will define the cost of all App Services that use this plan!

### App Service

[Windows App Service Reference Documentation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_web_app)
[Linux App Service Reference Documentation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_web_app)
note that the Windows and Linux app services use different documentation. You must use the OS that is aligned with the App Service Plan being used.

1. Check if there is an existing App Service Plan that meets the criteria for the App Service. App Service Plans define an operating system and machine tier which controls the hardware specs and cost of App Services
2. If there is not an existing App Service Plan that meets your needs, follow the [Adding an App Service Plan](#app-service-plan)
3. Copy the reference documentation example (We chose the linux variant for this example)

```
resource "azurerm_linux_web_app" "example" {
  name                = "example"
  resource_group_name = azurerm_resource_group.example.name
  location            = azurerm_service_plan.example.location
  service_plan_id     = azurerm_service_plan.example.id

  site_config {}
}
```

4. Add it to the terraform main.tf file (add to a different file if using a more complex file structure)
5. Give the resource a name `resource "azurerm_linux_web_app" "<name goes here>" {`
6. Update the resource group name arguments to use the resource group resource (e.g. Given resource group definition `data "azurerm_resource_group" "rg" {`, the location argument would have a value of `data.azurerm_resource_group.rg.location`). This resource group should match the resource group in the service plan.
7. Update the location and service_plan_id arguments to reference the App Service Plan resource (e.g. Given App Service Plan definition `resource "azurerm_service_plan" "example" {`, the location argument would have a value of `azurerm_service_plan.example.location`).
8. Update the name argument. The Name argument is what you will see inside the azure portal.
9. Add optional arguments. The following are recommended:
   - https_only - set to true; this may be required by policy
   - tags {} - add tags to the machine
   - site_config {} - a broad object with a lot of arguments; refer to implementations in main.tf and official docs.

# DO NOT DELETE THIS
Ever. These resources are used by all clients and need to be working. The resources include

- Shared Resource Group
- Shared Azure Container Registry (ACR)
- Key Vault, Storage Account and Networking Settings for the Resource Group and ACR

# Updaing This
Do it carefully. Terraform apply has been run once, do not overwrite it unless you are told to. If you don't know what these terms mean, you do not need to be in this directory whatsoever.
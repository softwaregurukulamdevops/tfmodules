# Managed Identity Module

This Terraform module creates an Azure User Assigned Managed Identity with optional role assignments.

## Features

- Creates a User Assigned Managed Identity
- Supports multiple role assignments with flexible scopes
- Configurable naming convention
- Optional custom role assignments with specific scopes
- Comprehensive outputs for integration with other modules

## Usage

### Basic Usage

```terraform
module "managed_identity" {
  source = "../../modules/managed_identity"
  
  environment     = "dev"
  location        = "eastus2"
  instance_number = "01"
  
  rg = {
    name     = azurerm_resource_group.example.name
    location = azurerm_resource_group.example.location
  }
}
```

### With Role Assignments

```terraform
module "managed_identity" {
  source = "../../modules/managed_identity"
  
  environment     = "dev"
  location        = "eastus2"
  instance_number = "01"
  
  rg = {
    name     = azurerm_resource_group.example.name
    location = azurerm_resource_group.example.location
  }
  
  # Basic role assignments (uses the scope variable)
  scope            = azurerm_resource_group.example.id
  role_assignments = [
    "Contributor",
    "Storage Blob Data Contributor"
  ]
  
  # Custom role assignments with specific scopes
  custom_role_assignments = {
    "key_vault_access" = {
      role  = "Key Vault Secrets User"
      scope = azurerm_key_vault.example.id
    }
    "acr_pull" = {
      role  = "AcrPull"
      scope = azurerm_container_registry.example.id
    }
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | Environment name (e.g., dev, staging, prod) | `string` | n/a | yes |
| location | Azure region where resources will be created | `string` | n/a | yes |
| instance_number | Instance number for resource naming | `string` | n/a | yes |
| rg | Resource group object containing location and name | `object` | n/a | yes |
| role_assignments | List of role definitions to assign to the managed identity | `list(string)` | `[]` | no |
| scope | Scope for role assignments (resource group, subscription, etc.) | `string` | `""` | no |
| custom_role_assignments | Map of custom role assignments with specific scopes | `map(object)` | `{}` | no |
| create_system_identity | Whether to create a system-assigned managed identity | `bool` | `false` | no |
| tags | Additional tags to apply to the managed identity | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| managed_identity_id | The ID of the user assigned managed identity |
| managed_identity_principal_id | The principal ID of the user assigned managed identity |
| managed_identity_client_id | The client ID of the user assigned managed identity |
| managed_identity_name | The name of the user assigned managed identity |
| managed_identity_tenant_id | The tenant ID of the user assigned managed identity |

## Common Role Assignments

- `Contributor` - Full access to manage all resources
- `Reader` - Read-only access to resources
- `Storage Blob Data Contributor` - Read, write, and delete Azure Storage blob containers and data
- `Key Vault Secrets User` - Read secret contents from Key Vault
- `AcrPull` - Pull images from Azure Container Registry
- `SQL DB Contributor` - Manage SQL databases
- `Cognitive Services User` - Read and list keys of Cognitive Services

## Integration Examples

### With App Service
```terraform
resource "azurerm_linux_web_app" "example" {
  # ... other configuration ...
  
  identity {
    type         = "UserAssigned"
    identity_ids = [module.managed_identity.managed_identity_id]
  }
}
```

### With Container Instance
```terraform
resource "azurerm_container_group" "example" {
  # ... other configuration ...
  
  identity {
    type         = "UserAssigned"
    identity_ids = [module.managed_identity.managed_identity_id]
  }
}
```

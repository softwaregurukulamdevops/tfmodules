# Terraform Scripts

## Service Info

Monicre: `tf`
These terraform scripts were created for Azure

- Subscription: WorkWise
- Resource Groups: rg-workwise-shared-eastus2-01, rg-infra-setup-eastus2-01 (our dev environment)

The basic architecture plan is as follows

[technical-architecture](/terraform/docs/Test-Pilot-Technical-Architecture.jpg)

## Running Terraform

### Configuration

The following variables are expected to be provided to the terraform runner. These can be provided in a tfvars file or by command line.

| Variable Name         | Type   | Description                                                                                      |
| ----------------------| ------ | ------------------------------------------------------------------------------------------------ |
| db_login_name         | string | login username of the DB                                                                         |
| environment           | string | Name of the environment. Will be included in all resource names                                  |
| simple_env_name       | string | Environment name without any dashes or special characters, used for key vault                    |
| instance_number       | string | Instance number for the environment, usually set to "01"                                         |
| location              | string | Deployment location; must match with an official region (see below for more info)                |
| semver                | string | Docker tag that will be applied to all containers                                                |
| shared_rg_name        | string | Name of the shared resource group, containing terraform state files and azure container registry |
| DB_PASSWORD           | string | Default DB password. Note: This will be removed/altered in a future release                      |
| SSL_CERT_SECRET_NAME  | string | Name of the secret in Key Vault for the SSL certificate password                                 |
| acr_chat_image_name   | string | Name of the Chat Service docker image in the format {repository}:{tag}                           |
| acr_file_image_name   | string | Name of the File Service docker image in the format {repository}:{tag}                           |
| acr_portal_image_name | string | Name of the Portal docker image in the format {repository}:{tag}                                 |

### Sample Config
Currently these are the values being passed into the command line once terraform "plan" or "apply is run are:
```
db_login_name         = "workwiseadmin"
environment           = "<replace-with-your-environment-name>"
simple_env_name       = "<replacewithyourenvironmentname>"
instance_number       = "01"
location              = "eastus2"
semver                = "latest"
shared_rg_name        = "rg-workwise-shared-eastus2-01"
shared_acr_name       = "crinfrasetup01"
DB_PASSWORD           = "<reach_out_to_a_dev>"
SSL_CERT_SECRET_NAME  = "SSL-CERT-PASSWORD"
acr_chat_image_name   = "chat-service:latest"
acr_file_image_name   = "file-service:latest"
acr_portal_image_name = "portal:latest"
```

Please ask a developer on the team for the DB_PASSWORD

#### Note: Upcoming DB_PASSWORD Replacement
When creating a database instance, a password should be generated with random password provider.
The resource [random_string] or [random_password] generates a random permutation of alphanumeric characters and optionally special characters.
This resource does use a cryptographic random number generator.
Reference document - https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password
Example below:

```
resource "random_password" "password" {
  length           = 16
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

resource "example_db_instance" "example" {
  ...
  password          = random_password.password.result
}
```

### Azure CLI Configuration

**If deploying a new instance of Workwise the Azure CLI needs the right subscription**.

Ensure the Azure CLI is installed, if not install using the following commands:

1. Install azure cli with `brew install azure-cli`
2. Login to azure with `az login` (Must be connected to VPN)

Set the subscription in azure cli with `az account set --subscription=<SUBCSRIPTION_ID>`


## First Time Run

To install terraform on your local machine read the [terraform local setup docs](/docs/local-setup/terraform.md)

These steps assume terraform is installed on your local machine and azure login is configured. To install terraform on your local machine follow the [terraform local setup docs](/docs/local-setup/terraform.md)

1. Open a terminal and navigate to the `/terraform/environments` directory within this project
2. Create a new folder for you environment. Run `cp infra-setup/* <your-env-name/>`
3. Change the `key` field within the backend block of the provider.tf file in your environment folder. Make it `yourenvname.terraform.tfstate`
4. Initialize terraform with `terraform init`
5. Run `terraform plan` to see what changes would occur if the current tf scripts were applied
6. Once sure, run `terraform apply` to deploy changes. 

## Post Run Manual Steps

1. Go to the portal's networking settings and allow public access (this is temporary)
2. Add an access policy for the key vault and add a secret "OPENAI-API-KEY"
3. Add another key vault secret named "SSL-CERT-PASSWORD".  If there is so SSL certificate password, then set `SSL_CERT_SECRET_NAME` in the `terraform.tfvars` to "" (empty string)
4. Add or update the values of three variables in the `.env` file located in both `microservices/chat/src/` and `microservices/file-processing/src/`: **DB_URL_PARAMETER_HOST**, **DB_URL_PARAMETER_DATABASE**, **APPSETTING_KEY_VAULT_NAME**
5. Provision the DB tables using CREATE scripts `python microservices/chat/src/run-alembic.py --upgrade --local` and `python microservices/file-processing/src/run-alembic.py --upgrade --local`
6. Add the DB to the virtual network (if necessary)
7. Change remaining APPSETTINGS pointing to testpilot (this is temporary)
8. Restart the backend app services

## New Developer Setup (dev-env environment)

These steps assume that the terraform .tfstate remote backend was already set up by another developer, and all Azure infrastructure has already been deployed via Terraform.

These steps also assume that terraform is installed on your local machine and Azure CLI is configured properly (See the Azure CLI Configuration section)

1. Make sure you are on the US-GDC-GP-NodeA or US-GDC-GP-NodeB VPN
2. Pull in the latest code from the TestPilot `main` branch in Azure DevOps
3. In your terminal navigate to the `/terraform/environments/dev-env` directory
4. In this directory, initialize terraform with `terraform init`.  This will initialize your local terraform environment to sync with the dev-env environment that was already deployed in Azure.  This is accomplished by syncing with the remote backend's .tfstate file
5. Run `terraform plan` to check the dev-env infrastructure for WorkWise.  You should **NOT** see any changes in this plan.  If you see any changes (or additions or deletions), reach out to another developer to sort them out **BEFORE** continuing
6. Now that your terraform plan shows 0 changes, you can develop without worrying about breaking existing functionality prior to your onboarding.  Your future terraform commands will always reference the current state of the dev-env infrastructure

## Resources

This section describes all of the resources that can be found in the main.tf file.

- azurerm_service_plan.linux-f1 - Free tier linux app service plan

### AI Service

## Azure Regions / Locations

. For a list of all Azure locations run `az account list-locations --output table`

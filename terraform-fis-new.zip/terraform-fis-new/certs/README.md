# SSL Certificate Files

This directory contains SSL certificates for the Application Gateway.

## Development Certificate

For development purposes, you can create a self-signed certificate using:

```powershell
# Create a self-signed certificate
$cert = New-SelfSignedCertificate -DnsName "*.consult.llm.pwc.com", "consult.llm.pwc.com" -CertStoreLocation "cert:\CurrentUser\My" -KeyAlgorithm RSA -KeyLength 2048 -NotAfter (Get-Date).AddYears(2)

# Export to PFX file
$password = ConvertTo-SecureString -String "Password!" -Force -AsPlainText
Export-PfxCertificate -Cert $cert -FilePath "_.consult.llm.pwc.com.pfx" -Password $password

# Clean up from certificate store
Remove-Item -Path "cert:\CurrentUser\My\$($cert.Thumbprint)" -Force
```

## Production Certificate

For production, replace the development certificate with a proper SSL certificate from a trusted Certificate Authority (CA).

## File Location

The certificate file should be named: `_.consult.llm.pwc.com.pfx`
Password: `Password!` (as configured in terraform.tfvars)
